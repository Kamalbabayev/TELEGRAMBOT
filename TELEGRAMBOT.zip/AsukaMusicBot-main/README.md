 ### 🅰︎sᴜᴋᴀ 🅼︎ᴜsɪᴄ 🅱︎ᴏᴛ

### ᴀɴ ᴀᴅᴠᴀɴᴄᴇᴅ ᴘʀᴇᴍɪᴜᴍ ᴍᴜsɪᴄ ʙᴏᴛ ғᴏʀ ᴛᴇʟᴇɢʀᴀᴍ ɢʀᴏᴜᴘ ᴠᴏɪᴄᴇ ᴄʜᴀᴛ ᴅᴇᴠᴇʟᴏᴘᴇᴅ ʙʏ sᴜᴍɪᴛ ʏᴀᴅᴀᴠ.

<p align="center"><a href="https://t.me/World_FriendShip_Zone"><img src="https://te.legra.ph/file/3752041b671e0afc6ada2.jpg"></a></p>


 <h3 align="center">
    ─ ᴅᴇᴩʟᴏʏ ᴏɴ ʜᴇʀᴏᴋᴜ ─
</h3>

<p align="center"><a href="https://dashboard.heroku.com/new?template=https://github.com/Sumit9969/AsukaMusicBot"> <img src="https://img.shields.io/badge/Deploy%20On%20Heroku-black?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>


### sᴛʀɪɴɢ sᴇssɪᴏɴ

[![GenerateString](https://img.shields.io/badge/repl.it-generateString-black)](https://t.me/Hana_Session_Bot)


### ꜱᴜᴘᴘᴏʀᴛ ᴀɴᴅ ᴜᴘᴅᴀᴛᴇꜱ
<a href="https://t.me/TechQuardSupport"><img src="https://img.shields.io/badge/Join-Group%20Support-black.svg?style=for-the-badge&logo=Telegram"></a> <a href="https://t.me/TechQuard"><img src="https://img.shields.io/badge/Join-Updates%20Channel-black.svg?style=for-the-badge&logo=Telegram"></a>

 
